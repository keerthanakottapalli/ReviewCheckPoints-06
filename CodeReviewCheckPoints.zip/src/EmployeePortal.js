import React, { useState, useEffect } from 'react';
import {
    Table,
    TableHead,
    TableRow,
    TableCell,
    TableBody,
    Checkbox,
    TextField,
    Input,
    Tab,
    Tabs,
    Button,
} from '@mui/material';
import {
    AppBar, Toolbar, Typography
} from '@mui/material';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import firebase from 'firebase/compat/app';
import 'firebase/compat/storage';

import axios from 'axios';
import './EmployeePortal.css'
import { Link, useNavigate } from 'react-router-dom';

export default function EmployeePortal() {
    const navigate = useNavigate();


    // Initialize Firebase with your configuration
    const firebaseConfig = {
        apiKey: "AIzaSyDD6YZm2vcDGYrPoMJGN6WPWTluyzKahSk",
        authDomain: "clouddemo-2e42b.firebaseapp.com",
        projectId: "clouddemo-2e42b",
        storageBucket: "clouddemo-2e42b.appspot.com",
        messagingSenderId: "644022241974",
        appId: "1:644022241974:web:7ed1bf6cf3ca496763b417",
        measurementId: "G-25998DYZT5"
    };

    if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
    }

    const storage = firebase.storage();

    const [adminData, setAdminData] = useState({});
    const [employeeData, setEmployeeData] = useState([]);
    const [openDialog, setOpenDialog] = useState(false);
    const [selectedTab, setSelectedTab] = useState(0);
    const [tabData, setTabData] = useState([]);
    const [rowFiles, setRowFiles] = useState(Array(100).fill(null));
    const [rowIndex, setRowIndex] = useState();
    const [counter, setCounter] = useState(1000);

    const handleClose = () => {
        setOpenDialog(false);
        navigate('/EmployeeMainView');
    };

    const handleTabChange = (event, newValue) => {
        setSelectedTab(newValue);
    };

    const tabLabels = [...new Set(employeeData.map((data) => data.Value))];

    useEffect(() => {
        // Fetch admin data
        const adminApiUrl = 'http://172.17.15.253:8080/adminReviewGetData';

        axios
            .get(adminApiUrl)
            .then((response) => {
                const adminData = response.data;
                setAdminData(adminData);
                console.log('Admin Data:', adminData);

                // Initialize employee data based on admin data
                const initialEmployeeData = Object.keys(adminData).reduce(
                    (result, key) => {
                        const reviewPoints = adminData[key]['Review Points'];

                        const employeePoints = reviewPoints.map((point, index) => ({
                            Value: key,
                            ReviewPoint: point,
                            SelfReview: false,
                            Reviewver: false,
                            Comments: '',
                        }));

                        return [...result, ...employeePoints];
                    },
                    []
                );

                setEmployeeData(initialEmployeeData);
                console.log('Initial Employee Data:', initialEmployeeData);
            })
            .catch((error) => {
                console.error('Error fetching admin data', error);
            });
    }, []);

    useEffect(() => {
        // Create data for each tab and update the tabData state variable
        const dataForTabs = tabLabels.map((label) => {
            return employeeData.filter((data) => data.Value === label);
        });
        setTabData(dataForTabs);
    }, [employeeData, tabLabels]);


    const handleButtonClick = (tabIndex, dataIndex, value) => {
        const updatedTabData = [...tabData];
        // console.log(tabData,"tabdata...");
        updatedTabData[tabIndex][dataIndex].SelfReview = value;
        setTabData(updatedTabData);
    };



    const handleFileChangeForRow = (e, rowIndex) => {
        const selectedFile = e.target.files[0];
        console.log(selectedFile.name, "selectedFile");
    
        // Update the rowIndex in the state
        setRowIndex(rowIndex);
    
        setRowFiles((prevRowFiles) => {
            const newFiles = [...prevRowFiles];
            newFiles[rowIndex] = selectedFile;
            return newFiles;
        });
    };
    

    var sequentialNumber

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('token');



        const parseJWT = (token) => {
            const base64Url = token.split('.')[1];
            const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
            const decodedData = JSON.parse(atob(base64));
            return decodedData;
        };

        const tokenData = parseJWT(token);
        const empId = tokenData.Empid;
        const empName1 = tokenData.Firstname;
        const empName2 = tokenData.Lastname;
        const fullName = empName1 + ' ' + empName2;

        try {
            let counter = 1000;
            const formattedData = {
                data: tabData.map((tab, tabIndex) => {
                    return {
                        empid: empId,
                        empname: fullName,
                        ratings: tab.map((item, dataIndex) => {
                            sequentialNumber = `Rid${counter.toString().padStart(4, '0')}`;
                            counter += 1;

                            return {
                                Em_Id: sequentialNumber,
                                value: item.Value,
                                review_points: [
                                    {
                                        review_point: item.ReviewPoint,
                                        self_review: item.SelfReview,
                                        uploadImage: rowFiles[tabIndex],
                                    },
                                ],
                            };
                        }),
                    };
                }),
            };

            console.log('Formatted Data:', formattedData);
            const apiUrl = 'http://172.17.15.253:8080/insertReviewPoints';

            await axios.post(apiUrl, formattedData);

            setOpenDialog(true);

        } catch (error) {
            console.error('Error in handleSubmit:', error);
        }
    };



    const handleUploadForRow = async (event, tabIndex) => {
        console.log(rowIndex, "rowIndex");
        const token = localStorage.getItem('token');
        const parseJWT = (token) => {
            const base64Url = token.split('.')[1];
            const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
            const decodedData = JSON.parse(atob(base64));
            return decodedData;
        };
    
        const tokenData = parseJWT(token);
        const empId = tokenData.Empid;
        const empName1 = tokenData.Firstname;
        const empName2 = tokenData.Lastname;
        const fullName = empName1 + ' ' + empName2;
    
        try {
            const selectedFile = rowFiles[rowIndex];
            console.log();
    
            if (selectedFile) {
                // Use the current value of the counter
                
                const sequentialNumber = `Rid${rowIndex.toString().padStart(4, '0')}`;
                console.log(sequentialNumber, "sequentialNumber");
    
                // Update the counter using a functional update to ensure it's based on the current state
                setCounter((prevCounter) => prevCounter + 1);
    
                const storageRef = storage.ref(`uploads/${sequentialNumber}`);
                await storageRef.put(selectedFile);
                const downloadURL = await storageRef.getDownloadURL();
    
                // Create the formatted data for the selected row
                const formattedData = {
                    data: [
                        {
                            empid: empId,
                            empname: fullName,
                            ratings: [
                                {
                                    Em_Id: sequentialNumber[rowIndex],
                                    value: tabData[rowIndex].Value,
                                    review_points: [
                                        {
                                            review_point: tabData[rowIndex].ReviewPoint,
                                            self_review: tabData[rowIndex].SelfReview,
                                            uploadImage: downloadURL,
                                        },
                                    ],
                                },
                            ],
                        },
                    ],
                };
    
                console.log('Formatted Data:', formattedData);
            } else {
                console.error('No file selected for upload');
            }
        } catch (error) {
            console.error('Error uploading file:', error);
        }
    };
    
    
    


    const firstname = localStorage.getItem('firstname');
    const lastname = localStorage.getItem('lastname');
    const username = firstname + " " + lastname

    return (
        <>
            <AppBar position="fixed">
                <Toolbar className="navBar-style">

                    <div className="userInfo">
                        <Typography variant="h6" className="welcome-text">
                            Welcome
                        </Typography>

                        <h3 className="username-style">{username}</h3>
                    </div>
                    <Button color="inherit" onClick={handleClose} className='buttonwrapper'>
                        <span className='gobackeform'

                        >
                            &#8629;
                        </span>&nbsp;
                        <b>GoBack</b>
                    </Button>
                </Toolbar>
            </AppBar>
            <br /><br /><br /><br />
            <form onSubmit={handleSubmit} >
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', maxWidth: '80%', margin: '0 auto' }}>
                    <Tabs value={selectedTab} onChange={handleTabChange}>
                        {tabLabels.map((label, index) => (
                            <Tab label={label} key={index} style={{ fontWeight: 'bold', fontSize: '18px' }} />
                        ))}
                    </Tabs>
                </div>
                <br />
                <div style={{ maxWidth: '90%', margin: '0 auto', backgroundColor: '#f5f5f5' }}>
                    <div style={{ height: '500px', overflowY: 'auto', border: '1px solid #c7c7c7' }}>
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <TableCell style={{ fontSize: '20px' }}><b>Review Point</b></TableCell>
                                    <TableCell style={{ fontSize: '20px' }}><b>Self-Review</b></TableCell>
                                    <TableCell style={{ fontSize: '20px' }}><b>Upload Image</b></TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {employeeData
                                    .filter((data) => data.Value === tabLabels[selectedTab])
                                    .map((data, index) => (
                                        <TableRow key={index}>
                                            <TableCell>{data.ReviewPoint}</TableCell>
                                            <TableCell>
                                                <Button
                                                    variant="outlined"
                                                    type="button"
                                                    className={`yes-button ${data.SelfReview ? 'selected' : ''}`}
                                                    onClick={() => handleButtonClick(selectedTab, index, true)}
                                                >
                                                    Yes
                                                </Button>
                                                <Button
                                                    variant="outlined"
                                                    type="button"
                                                    className={`no-button ${!data.SelfReview ? 'selected' : ''}`}
                                                    onClick={() => handleButtonClick(selectedTab, index, false)}
                                                >
                                                    No
                                                </Button>

                                            </TableCell>
                                            <TableCell>
                                                <Input type="file" onChange={(e) => handleFileChangeForRow(e, index)} />
                                                <Button type="button" variant="outlined" onClick={(e) => handleUploadForRow(e, index)}>
                                                    Upload
                                                </Button>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                            </TableBody>

                        </Table>
                    </div>
                </div>
                <br />
                <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    style={{
                        position: 'fixed',
                        bottom: '0',
                        right: '180px',
                        marginBottom: '40px',
                    }}
                >
                    Submit
                </Button>

                <Dialog open={openDialog} onClose={handleClose}>
                    <DialogContent style={{ width: '420px' }}>
                        <img
                            src="https://badge-exam.miraclesoft.com/assets/ecert/Completed-test.svg"
                            alt="Your Image Alt Text"
                            style={{ maxWidth: '100%', maxHeight: '200px', marginLeft: '23%' }}
                        />
                        <DialogContentText style={{ fontSize: '18px', textAlign: 'center', fontWeight: 'bold', color: '#1dbb99' }}>
                            Successfully filled the form. Click OK to Login
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleClose} color="primary" style={{ color: 'black', backgroundColor: '#d8d6d6', fontWeight: 'bolder' }}>
                            OK
                        </Button>
                    </DialogActions>
                </Dialog>
            </form>

        </>
    );
}
